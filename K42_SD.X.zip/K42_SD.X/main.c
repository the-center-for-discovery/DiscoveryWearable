
// include necessary libraries
#include "mcc_generated_files/mcc.h"

#include<stdio.h>
#include<string.h>


//define I2C slave and data addresses
#define MCP9808_I2C_SLAVE_ADDR 0x18
#define MCP9808_RESGISTER_TEMP_ADDR 0x05

#define XL_I2C_SLAVE_ADDR 0x6A
#define XL_X 0x28
#define XL_Y 0x2A
#define XL_Z 0x2C

#define RTC_SLAVE_ADDR 0x6F
#define RTCSEC_ADDR 0x00
#define RTCMIN_ADDR 0x01
#define RTCHOUR_ADDR 0x02

// variables needed for SD card
FATFS drive;
FIL file;



void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    
    //instantiate needed variables
    uint16_t sensor_val = 0;
    uint16_t adc = 0;
    
    uint16_t X = 0;
    uint16_t Y = 0;
    uint16_t Z = 0;
    
    float microsiemens = 0;
    float temp = 0;
    
    UINT actualLength;
    char data[] = "                                                           ";
    
    
    //write the current time
    i2c_write1ByteRegister(RTC_SLAVE_ADDR, RTCSEC_ADDR, 0xFF);
    i2c_write1ByteRegister(RTC_SLAVE_ADDR, RTCMIN_ADDR, 0x1E);
    i2c_write1ByteRegister(RTC_SLAVE_ADDR, RTCHOUR_ADDR, 0x07);
    
    uint8_t  currentsec = 0;
    uint8_t  currentmin = 0;
    uint8_t  currenthour = 0;
       
    
    while (1)
    {
    //turn on LED
    RA1 = 1;
    
    //read accel data, in X, Y, and Z
    X = i2c_read2ByteRegister(XL_I2C_SLAVE_ADDR, XL_X);
    X = X/2560;
    Y = i2c_read2ByteRegister(XL_I2C_SLAVE_ADDR, XL_Y);
    Y = Y/2560;
    Z = i2c_read2ByteRegister(XL_I2C_SLAVE_ADDR, XL_Z);
    Z = Z/2560;
    
    //get GSR data and convert to microsiemens
    adc = ADCC_GetSingleConversion(GSR);
    microsiemens = adc;
    microsiemens = microsiemens * 1000000 / (4095 * 150000);  
    
    //get current time
    currentsec = i2c_read1ByteRegister(RTC_SLAVE_ADDR, RTCSEC_ADDR);
    currentsec = currentsec & 0x7F;
    currentmin = i2c_read1ByteRegister(RTC_SLAVE_ADDR, RTCMIN_ADDR);
    currentmin = currentmin & 0x7F;
    currenthour = i2c_read1ByteRegister(RTC_SLAVE_ADDR, RTCHOUR_ADDR);
    currenthour = currenthour & 0x3F;
    
    // get temp data
    sensor_val = i2c_read2ByteRegister(MCP9808_I2C_SLAVE_ADDR, MCP9808_RESGISTER_TEMP_ADDR);
    
    //convert to F
        if (sensor_val != 0xFFFF) {
                temp = sensor_val & 0x0FFF;
                temp /= 16.0;
                    if (sensor_val & 0x1000)
                        temp -= 256;

                temp = temp * 9.0 / 5.0 + 32;} 
                
                
    if( SD_SPI_IsMediaPresent() == false)
    {
        return;
    }    
        
         if (f_mount(&drive,"0:",1) == FR_OK)  //mount
    {
       if (f_open(&file, "TEST.TXT", FA_WRITE | FA_OPEN_APPEND ) == FR_OK) { //Open or Create TEST.TXT file
           
            //write data to sd card
            sprintf(data, "%-4i:%-4i:%-4i,", currenthour, currentmin, currentsec);
            f_write(&file, data, sizeof(data)-1, &actualLength );
            sprintf(data, "%-4i,%-4f,%-4f,", adc, microsiemens, temp);
            f_write(&file, data, sizeof(data)-1, &actualLength );
            sprintf(data, "%-4i,%-4i,%-4i\r\n", X, Y, Z);
            f_write(&file, data, sizeof(data)-1, &actualLength );

            
            f_close(&file);
       }
   
        f_mount(0,"0:",0);  //unmount disk
    }
        
        
        //turn off LED and wait a second
         RA1 = 0;
         __delay_ms(1000);
        
        
    }
}