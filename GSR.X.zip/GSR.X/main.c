
#include "mcc_generated_files/mcc.h"
#include<stdio.h>
#include<string.h>

FATFS drive;
FIL file;

void main(void)
{
   
    SYSTEM_Initialize();

    UINT actualLength;

    char data4[16];
    char spacer[] = "\r\n";
    //DWORD fs = f_size(&file);
   
    uint16_t pot = 0;
    
    if( SD_SPI_IsMediaPresent() == false)
    {
        return;
    }
 
       
    
    while (1)
    {
        

            if (f_mount(&drive,"0:",1) == FR_OK)  //mount
    {
        
        if (f_open(&file, "TEST4.TXT", FA_OPEN_APPEND | FA_READ | FA_WRITE ) == FR_OK) 
        { //Open or Create TEST.TXT file
           
             pot = ADCC_GetSingleConversion(POT);
             sprintf(data4, "%-4i,%-4i,%-4i\r\n", pot, pot, pot);
             //strcat(data4,spacer);
             //f_lseek(&file, f_size(&file));
             //f_write(&file, sizeof(fs), sizeof(fs)-1, &actualLength );
             //f_write(&file, pot, sizeof(pot)-1, &actualLength );
             f_write(&file, data4, sizeof(data4)-1, &actualLength );
             
            //pot = ADC_GetConversion(POT);
            //f_write(&file, pot, sizeof(pot)-1, &actualLength );
            //__delay_ms(1000);
             
        }
        
    }
    
        f_close(&file);
        f_mount(0,"0:",0);  //unmount disk
    }
    
    
    
}
