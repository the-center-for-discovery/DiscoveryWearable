

#include "mcc_generated_files/mcc.h"
#include<stdio.h>
#include<string.h>

#define MCP9808_I2C_SLAVE_ADDR 0x18
#define MCP9808_RESGISTER_TEMP_ADDR 0x05

FATFS drive;
FIL file;

/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    
    uint16_t sensor_val = 0;
    
    UINT actualLength;
    char data4[] = "4\r\n";
    
    //__delay_ms(500);
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();
    
    
    if( SD_SPI_IsMediaPresent() == false)
    {
        return;
    }
    
    while (1)
    {
        sensor_val = i2c_read2ByteRegister(MCP9808_I2C_SLAVE_ADDR, MCP9808_RESGISTER_TEMP_ADDR);
        sprintf(data4, "%-4i,%-4i,%-4i\r\n", sensor_val, sensor_val, sensor_val);
    
    if (f_mount(&drive,"0:",1) == FR_OK)  //mount
    {
        
        if (f_open(&file, "TEST0.TXT", FA_OPEN_APPEND | FA_READ | FA_WRITE ) == FR_OK) 
        { //Open or Create TEST.TXT file
           

             f_write(&file, data4, sizeof(data4)-1, &actualLength );
             
         }
        
    }
    
        f_close(&file);
        f_mount(0,"0:",0);  //unmount disk
    
    
    }
}
/**
 End of File
*/